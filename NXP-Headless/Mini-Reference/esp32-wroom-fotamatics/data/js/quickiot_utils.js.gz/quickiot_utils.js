
/**
 * QUICKIOT UTILITIES (quickiot_utils.js)
 *
 * This file contains global functions and variables for the QuickIoT application.
 * It should be loaded once in index.html and will be available to all
 * dynamically loaded content fragments.
 */

// --- Global Configuration & State Variables ---

// Set to true for local development to use mock data/endpoints
// Configuration for local vs. device testing
var LOCAL_HOST = false; // Set to true for local testing
var device_fixed_ip = '10.10.10.10';

// Auto-set LOCAL_HOST_IP based on LOCAL_HOST value
var LOCAL_HOST_IP;
if (LOCAL_HOST) {
    LOCAL_HOST_IP = '192.168.29.10:5500'; // Local development IP
} else {
    LOCAL_HOST_IP = device_fixed_ip; // Device IP
}

// Global objects to hold configuration and state data fetched from the device.
// Fragments will populate and read from these objects.
var g_device_id = null;
var g_device_params_db = {};
var g_register_db = {};
var g_dev_comm_db = {};
var g_wifi_db = {};
var g_modbus_driver_list = {};
var g_currentDriver = null;

// --- Core Utility Functions ---

/**
 * Checks if the current viewport width is considered mobile.
 * @returns {boolean} True if the window width is 992px or less.
 */
function Utils_isMobile() {
    return window.innerWidth <= 992; // Bootstrap's 'lg' breakpoint
}

/**
 * Determines if the device is in a mode that allows configuration changes.
 * Only allows configuration updates when the client IP is 10.10.10.10.
 * @returns {boolean} True if configuration is allowed.
 */
function Utils_allowConfigUpdate() {
    // Get the browser's IP address and check if it's 10.10.10.10
    const browserIP = Utils_getBrowserIP();

    if (LOCAL_HOST == true) {
        //this will be for testing...
        return true;
    } else {
        return browserIP === device_fixed_ip;
    }
}

/**
 * Gets the browser's IP address from the current window location.
 * @returns {string} The IP address without port.
 */
function Utils_getBrowserIP() {
    const hostname = window.location.hostname;
    // If it's localhost or 127.0.0.1, use the actual IP from LOCAL_HOST_IP
    if (hostname === 'localhost' || hostname === '127.0.0.1') {
        return LOCAL_HOST_IP.split(':')[0];
    }
    // For all other cases, extract IP without port
    return hostname.split(':')[0];
}

/**
 * A wrapper for the modern fetch API that mimics jQuery's success/error callbacks.
 * This makes it easy to use modern fetch without rewriting all your existing callbacks.
 * @param {string} url - The endpoint to fetch.
 * @param {object} options - Fetch options (method, headers, body, etc.).
 * @param {function} successCallback - Function to call on success (receives JSON/text data).
 * @param {function} errorCallback - Function to call on error.
 */
async function Utils_apiFetch(url, options, successCallback, errorCallback) {
    try {
        const response = await fetch(url, options);

        if (!response.ok) {
            // Throw an error to be caught by the catch block
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        // Check content type to decide whether to parse as JSON or return as text
        const contentType = response.headers.get("content-type");
        if (contentType && contentType.includes("application/json")) {
            const data = await response.json();
            if (successCallback) successCallback(data);
        } else {
            const data = await response.text();
            if (successCallback) successCallback(data);
        }
    } catch (error) {
        if (errorCallback) errorCallback(error);
    }
}

/**
 * Shows a Bootstrap alert notification with automatic dismissal.
 * Requires a notification alert container with ID 'notification_alert' in the page.
 * @param {string} message - The message to display in the notification.
 * @param {string} type - The type of alert ('success', 'error', 'warning', 'info').
 * @param {number} duration - Auto-hide duration in milliseconds (0 = no auto-hide).
 * @param {string|jQuery} buttonSelector - Optional button selector or jQuery object to disable during notification.
 * @param {string} closeButtonSelector - Optional close button selector (default: '#notification_close_btn').
 */
function Utils_showNotification(message, type = 'info', duration = 5000, buttonSelector = null, closeButtonSelector = '#notification_close_btn') {
    const alertClass = type === 'success' ? 'alert-success' : 
                      type === 'error' ? 'alert-danger' : 
                      type === 'warning' ? 'alert-warning' : 'alert-info';
    
    $('#notification_alert')
        .removeClass('alert-success alert-danger alert-warning alert-info')
        .addClass(alertClass)
        .find('#notification_text').html(message);
    
    $('#notification_alert').show();
    
    // Setup close button handler (remove any existing handlers first)
    $(closeButtonSelector).off('click.notification').on('click.notification', function() {
        $('#notification_alert').fadeOut();
        // Re-enable button when manually closed
        if (buttonSelector) {
            $(buttonSelector).prop('disabled', false);
        }
    });
    
    // Disable button if provided
    if (buttonSelector) {
        $(buttonSelector).prop('disabled', true);
    }
    
    // Auto-hide after duration and re-enable button
    if (duration > 0) {
        setTimeout(() => {
            $('#notification_alert').fadeOut();
            // Re-enable button when notification hides
            if (buttonSelector) {
                $(buttonSelector).prop('disabled', false);
            }
        }, duration);
    }
}

/**
 * Fetches the current sensor values from the device.
 * @param {function} successCallback - The function to handle the retrieved sensor data.
 * @param {function} errorCallback - The function to handle errors.
 */
function Utils_getSensorValues(successCallback, errorCallback) {
    const url = LOCAL_HOST ? `http://${LOCAL_HOST_IP}/getSensorValues` : '/getSensorValues';

    //Narrow down to the local endpoint for testing
    // url = "http://" + LOCAL_HOST_IP + "/getSensorValues"; // Update with your local endpoint

    Utils_apiFetch(url, { method: 'POST' }, successCallback, errorCallback);
}

/**
 * Fetches the general device parameters (like device ID, MAC, WiFi status).
 * @param {function} successCallback - The function to handle the retrieved device parameters.
 * @param {function} errorCallback - The function to handle errors.
 */
function Utils_getDeviceParams(successCallback, errorCallback) {
    const url = LOCAL_HOST ? `http://${LOCAL_HOST_IP}/getDeviceParams` : '/getDeviceParams';
    Utils_apiFetch(url, { method: 'POST' }, successCallback, errorCallback);
}

/**
 * Reads the device communication configuration file (dev_comm.json).
 * @param {function} callback - Function to execute after the file is successfully read.
 */
function Utils_readDevCommConfigFromFS(callback) {
    const url = LOCAL_HOST ? `http://${LOCAL_HOST_IP}/static/config/devComm.json` : '/config/devComm.json';
    Utils_apiFetch(url, {}, (data) => {
        g_dev_comm_db = data;
        if (callback) callback(data);
    });
}

/**
 * Reads the WiFi configuration file (wifi_config.json).
 * @param {function} callback - Function to execute after the file is successfully read.
 */
function Utils_updateWifiConfigFromFS(callback) {
    const url = LOCAL_HOST ? `http://${LOCAL_HOST_IP}/static/config/wifi.json` : '/config/wifi.json';
    Utils_apiFetch(url, {}, (data) => {
        g_wifi_db = data;
        if (callback) callback(data);
    });
}

/**
 * Reads the device registration file (registration.json).
 * @param {function} callback - Function to execute after the file is successfully read.
 */
function Utils_readRegistrationFile(callback) {
    const url = LOCAL_HOST ? `http://${LOCAL_HOST_IP}/static/config/registration.json` : '/config/registration.json';
    Utils_apiFetch(url, {}, (data) => {
        g_register_db = data;
        if (callback) callback(data);
    });
}

/**
 * Lists all Modbus driver files (mmd_*.json) from the 'drivers/' directory.
 * The result is stored in the global g_modbus_driver_list array.
 */
function Utils_getAllModbusDrivers() {
    const url = LOCAL_HOST ? `http://${LOCAL_HOST_IP}/listModbusDrivers` : '/listModbusDrivers';
    Utils_apiFetch(url, { method: 'POST' }, (data) => {
        g_modbus_driver_list = data;
    });
}

// --- COMMON DRIVER DROPDOWN POPULATION FUNCTION ---
/**
 * Populates a driver selection dropdown with all available drivers.
 * Only fetches the selected driver file when needed.
 * @param {string} selectId - The id of the <select> element to populate (e.g., 'driver-select' or 'dashboard-driver-select').
 * @param {function} onChange - Callback to run when a driver is selected (receives driver filename, isInitial).
 * @param {string} loaderId - Optional id of loader element to show/hide during loading.
 * @param {string} defaultDriver - Optional driver filename to select by default.
 */
function Utils_populateDriverDropdown(selectId, onChange, loaderId, defaultDriver) {
    var $driverSelect = $('#' + selectId).empty();
    if (loaderId) $('#' + loaderId).show();

    if (!window.g_modbus_driver_list || g_modbus_driver_list.length === 0) {
        $driverSelect.append('<option value="">No drivers found</option>');
        if (loaderId) $('#' + loaderId).hide();
        return;
    }

    // Use new structure: array of objects with json_filename, meter, name
    $.each(g_modbus_driver_list, function (i, driverObj) {
        var value = driverObj.json_filename;
        var meter = driverObj.meter || '';
        var name = driverObj.name || '';
        var label = meter && name ? meter + ' (' + name + ')' : value;
        $driverSelect.append($('<option>', {
            value: value,
            text: label
        }));
    });

    var firstDriver = defaultDriver || (g_modbus_driver_list[0] && g_modbus_driver_list[0].json_filename);
    if (firstDriver) {
        $driverSelect.val(firstDriver);
    }

    if (loaderId) $('#' + loaderId).hide();
    if (onChange) {
        $driverSelect.off('change').on('change', function () {
            onChange($(this).val(), false);
        });
        if (firstDriver) {
            onChange(firstDriver, true);
        }
    }
}

// --- COMMON DRIVER LOADING FUNCTION ---
/**
 * Loads a Modbus driver JSON file by filename and returns the parsed object.
 * @param {string} driverId - The filename of the driver to load (e.g., "mmd_1.json").
 * @param {function} onSuccess - Callback to run on success (receives driver JSON).
 * @param {function} onError - Callback to run on error (receives error object).
 * @param {string} loaderId - Optional id of loader element to show/hide during loading.
 */
function Utils_loadDriver(driverId, onSuccess, onError, loaderId) {
    if (!driverId) return;
    var url = 'drivers/' + driverId;
    if (typeof LOCAL_HOST !== 'undefined' && LOCAL_HOST) {
        url = 'http://' + LOCAL_HOST_IP + '/static/drivers/' + driverId + '?_t=' + new Date().getTime();
    }
    // Always add cache-busting query string to prevent caching
    // url += '?_t=' + new Date().getTime();
    
    if (loaderId) $('#' + loaderId).show();
    $.ajax({
        url: url,
        type: 'GET',
        dataType: 'json',
        success: function (response) {
            if (onSuccess) onSuccess(response);
        },
        error: function (err) {
            if (onError) onError(err);
        },
        complete: function () {
            if (loaderId) $('#' + loaderId).hide();
        }
    });
}

// Any other globally-used functions from your project can be added here.
// --- Generalized Cancel Button Callback ---
var global_timers = window.global_timers || [];
var global_event_sources = window.global_event_sources || [];

function Utils_cancelScreen() {
    $("#main-content-area").html("");
    $(".dynamic_script").remove();
    Utils_clearScriptTimersAndEvents();
    Utils_showVersion();
}

function Utils_clearScriptTimersAndEvents() {
    $("#main-content-area").html("");
    $(".dynamic_script").remove();
    //Clear all the global timers
    if (Array.isArray(global_timers)) {
        for (var i = 0; i < global_timers.length; i++) {
            clearTimeout(global_timers[i]);
        }
    }
    if (Array.isArray(global_event_sources)) {
        for (var i = 0; i < global_event_sources.length; i++) {
            if (global_event_sources[i] != null) {
                global_event_sources[i].close();
                global_event_sources[i] = null;
            }
        }
    }
}

function Utils_showVersion() {
    $("#main-content-area").css("display", "block");
    $("#main-content-area").html(`
        <div class="text-center p-5">
            <h4 class="text-muted">Welcome to QuickIoT</h4>
            <p class="text-muted">Please select an item from the menu to begin.</p>
        </div>
    `);
}

// For example, if 'reset_device()' needs to make an AJAX call:
function Utils_resetDevice() {
    if (confirm("Are you sure you want to restart the device?")) {
        Utils_apiFetch('/restart', { method: 'POST' }, 
            (response) => { alert("Device is restarting..."); },
            (error) => { alert("Failed to send restart command."); }
        );
    }
}

/**
 * Saves a Modbus driver JSON to the device (or local server), chunking if needed.
 * @param {object} driverObj - The driver object to save (must have driver_id).
 * @param {function} onSuccess - Callback on success (receives response JSON).
 * @param {function} onError - Callback on error.
 * @param {string} loaderId - Optional loader element id to show/hide during save.
 */
function Utils_saveDriverToDevice(driverObj, onSuccess, onError, loaderId) {
    if (!driverObj || !driverObj.driver_id) {
        if (onError) onError('Missing driver_id in driver object');
        return;
    }

    if (loaderId) $('#' + loaderId).show();
    var driver_file_str = JSON.stringify(driverObj);
    var data = {
        driver_id: driverObj.driver_id,
        fileSize: driver_file_str.length,
        driver_chunks: 0
    };
    const MAX_POST_SIZE = 1000;
    let ctr = 0;
    for (let i = 0; i < driver_file_str.length; i += MAX_POST_SIZE) {
        data["driver_file" + ctr] = driver_file_str.substring(i, i + MAX_POST_SIZE);
        ctr++;
    }
    data.driver_chunks = ctr;

    var url = "/saveNewModbusDriver";
    if (typeof LOCAL_HOST !== 'undefined' && LOCAL_HOST) {
        url = "http://" + LOCAL_HOST_IP + "/save_driver_to_device";
    }

    $.ajax({
        url: url,
        type: 'POST',
        data: data,
        dataType: 'json',
        success: function(response) {
            if (onSuccess) onSuccess(response);
        },
        error: function(xhr, status, err) {
            if (onError) onError(err || status);
        },
        complete: function() {
            if (loaderId) $('#' + loaderId).hide();
        }
    });
}